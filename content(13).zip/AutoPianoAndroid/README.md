# 自动弹琴 Android
GitHub Actions 会自动生成可安装的 Debug APK。

使用：安装 APK -> 开启无障碍服务 -> 输入 1~7 琴键的屏幕 X/Y 坐标 -> 输入曲谱 -> 开始。
曲谱当前格式：数字 1~7，以空格分隔。
