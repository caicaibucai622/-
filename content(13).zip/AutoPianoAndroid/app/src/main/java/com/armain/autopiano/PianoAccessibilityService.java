package com.armain.autopiano;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;
public class PianoAccessibilityService extends AccessibilityService {
 public static PianoAccessibilityService instance;
 @Override protected void onServiceConnected(){ instance=this; }
 @Override public void onAccessibilityEvent(AccessibilityEvent e){}
 @Override public void onInterrupt(){}
 @Override public void onDestroy(){ if(instance==this) instance=null; super.onDestroy(); }
 public void tap(float x,float y,long ms){ Path p=new Path(); p.moveTo(x,y); GestureDescription.Builder b=new GestureDescription.Builder(); b.addStroke(new GestureDescription.StrokeDescription(p,0,Math.max(1,ms))); dispatchGesture(b.build(),null,null); }
}
