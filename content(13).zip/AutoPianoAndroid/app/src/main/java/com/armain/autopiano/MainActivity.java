package com.armain.autopiano;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.net.Uri; import android.provider.Settings; import android.view.*; import android.widget.*; import java.util.*; import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
 LinearLayout root, coords; EditText score, interval; final ArrayList<EditText[]> keys=new ArrayList<>(); final AtomicBoolean stop=new AtomicBoolean(false); volatile boolean paused=false;
 @Override public void onCreate(Bundle b){super.onCreate(b); build();}
 TextView t(String s,int sp){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(Color.DKGRAY);v.setPadding(8,10,8,10);return v;}
 Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
 void build(){ScrollView sv=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,40);sv.addView(root);root.addView(t("自动弹琴 1.0",26));root.addView(t("先开启无障碍服务，再填写每个琴键的屏幕坐标。曲谱示例：1 2 3 4 5 4 3 2 1",15));
  Button acc=btn("① 开启无障碍服务");acc.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(acc);
  coords=new LinearLayout(this);coords.setOrientation(LinearLayout.VERTICAL);root.addView(t("琴键坐标（像素）",18));root.addView(coords); for(int i=1;i<=7;i++) addKey(i);
  score=new EditText(this);score.setHint("曲谱：1 2 3 4 5 6 7；用空格分隔");score.setMinLines(4);score.setText("1 2 3 4 5 6 7 7 6 5 4 3 2 1");root.addView(score);
  interval=new EditText(this);interval.setHint("音符间隔毫秒");interval.setInputType(2);interval.setText("300");root.addView(interval);
  LinearLayout row=new LinearLayout(this);Button start=btn("开始");Button pause=btn("暂停/继续");Button st=btn("停止");row.addView(start);row.addView(pause);row.addView(st);root.addView(row);
  start.setOnClickListener(v->play());pause.setOnClickListener(v->paused=!paused);st.setOnClickListener(v->stop.set(true));setContentView(sv);
 }
 void addKey(int n){LinearLayout r=new LinearLayout(this);TextView l=t("键"+n,16);EditText x=new EditText(this),y=new EditText(this);x.setHint("X");y.setHint("Y");x.setInputType(2);y.setInputType(2);r.addView(l,new LinearLayout.LayoutParams(0,-2,1));r.addView(x,new LinearLayout.LayoutParams(0,-2,2));r.addView(y,new LinearLayout.LayoutParams(0,-2,2));coords.addView(r);keys.add(new EditText[]{x,y});}
 int num(EditText e){try{return Integer.parseInt(e.getText().toString().trim());}catch(Exception ex){return -1;}}
 void play(){if(PianoAccessibilityService.instance==null){Toast.makeText(this,"请先在系统设置中开启本应用的无障碍服务",Toast.LENGTH_LONG).show();return;} String[] ns=score.getText().toString().trim().split("\\s+");int gap=Math.max(30,num(interval));stop.set(false);paused=false;new Thread(()->{for(String s:ns){if(stop.get())break;while(paused&&!stop.get())SystemClock.sleep(80);try{int k=Integer.parseInt(s)-1;if(k>=0&&k<keys.size()){int x=num(keys.get(k)[0]),y=num(keys.get(k)[1]);if(x>=0&&y>=0)PianoAccessibilityService.instance.tap(x,y,40);}SystemClock.sleep(gap);}catch(Exception ignored){}}}).start();}
}
