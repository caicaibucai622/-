plugins { id("com.android.application") }

android {
    namespace = "com.armain.autopiano"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.armain.autopiano"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }
}
